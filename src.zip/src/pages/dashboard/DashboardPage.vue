<script setup>
import { computed, ref, watch } from 'vue'

import { RouterLink } from 'vue-router'

import BaseCard from '@/components/ui/BaseCard.vue'
import BaseButton from '@/components/ui/BaseButton.vue'
import BaseModal from '@/components/ui/BaseModal.vue'

import { useAuthStore } from '@/stores/useAuthStore'
import { useUserStore } from '@/stores/useUserStore'
import { useMemberStore } from '@/stores/useMemberStore'
import { useClassScheduleStore } from '@/stores/useClassScheduleStore'
import { useCheckinStore } from '@/stores/useCheckinStore'
import { usePosStore } from '@/stores/usePosStore'
import { useModuleStore } from '@/stores/useModuleStore'
import { useDashboardSummaryStore } from '@/stores/useDashboardSummaryStore'
import { useBranchesStore } from '@/stores/useBranchesStore'

import { isManager as isManagerRole } from '@/config/permissions'
import { toDateOnly, todayISO as getTodayISO } from '@/utils/date'
import { formatCheckinReason, formatCheckinMethod, formatCheckinRole } from '@/utils/checkinLabels'

const authStore = useAuthStore()
const userStore = useUserStore()
const memberStore = useMemberStore()
const scheduleStore = useClassScheduleStore()
const checkinStore = useCheckinStore()
const posStore = usePosStore()
const moduleStore = useModuleStore()
const summary = useDashboardSummaryStore()
const branches = useBranchesStore()
watch(
  () => [branches.activeBranchId, authStore.role],
  async ([branch, role]) => {
    if (branch && ['admin', 'owner'].includes(role)) await summary.load(branch).catch(() => {})
  },
  { immediate: true },
)
const daily = computed(() => (summary.branchId === branches.activeBranchId ? summary.data : null))
const money = (value) =>
  new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: daily.value?.currency || 'MXN',
  }).format(Number(value ?? 0))

const isAdmin = computed(() => authStore.role === 'admin')
const isOwner = computed(() => authStore.role === 'owner')
const isManager = computed(() => isManagerRole(authStore.role))
const isTrainer = computed(() => authStore.role === 'trainer')

const todayISO = getTodayISO()

const activeMembers = computed(() => memberStore.activeMembers.length)
const activeTrainers = computed(() => userStore.trainers.filter((user) => user.active).length)

const todayClasses = computed(() => {
  return scheduleStore.classes.filter((branchClass) => branchClass.date === todayISO)
})

const todayCheckins = computed(() => checkinStore.grantedToday)

// No hay un endpoint de ocupación total. Mostrar solo métricas verificadas.
const occupancy = computed(() => null)

const posSalesToday = computed(() => {
  return posStore.sales.filter((sale) => toDateOnly(new Date(sale.createdAt)) === todayISO)
})

const posRevenueToday = computed(() => {
  return posSalesToday.value.reduce((total, sale) => total + (Number(sale.total) || 0), 0)
})

const lowStockCount = computed(() => posStore.lowStockProducts.length)

const todaySchedule = computed(() => {
  return [...todayClasses.value].sort((a, b) => a.startTime.localeCompare(b.startTime))
})

const adminActivity = computed(() => {
  const checkinEvents = checkinStore.checkins.slice(0, 10).map((checkin) => ({
    id: `checkin-${checkin.id}`,
    title:
      checkin.allowed === false
        ? `Acceso denegado: ${checkin.userName}`
        : `${checkin.userName} hizo check-in`,
    description: checkin.allowed === false
      ? formatCheckinReason(checkin.reason)
      : `${formatCheckinMethod(checkin.method)} · ${formatCheckinRole(checkin.role)}`,
    timestamp: checkin.timestamp,
    type: checkin.allowed === false ? 'Acceso' : 'Check-in',
  }))

  const saleEvents = posStore.sales.slice(0, 10).map((sale) => ({
    id: `sale-${sale.id}`,
    title: `Venta #${sale.id} registrada`,
    description: `${sale.items.length} producto(s) · $${sale.total}`,
    timestamp: sale.createdAt,
    type: 'POS',
  }))

  return [...checkinEvents, ...saleEvents]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 10)
})

const trainerSales = computed(() => {
  return posStore.sales.filter((sale) => sale.createdBy === authStore.user?.id).slice(0, 10)
})

const detailOpen = ref(false)
const detailMetric = ref(null)

const openDetail = (metric) => {
  detailMetric.value = metric
  detailOpen.value = true
}

const closeDetail = () => {
  detailOpen.value = false
}

const hourlyOccupancy = computed(() => {
  const counts = Array.from({ length: 24 }, () => 0)

  checkinStore.grantedToday.forEach((checkin) => {
    counts[new Date(checkin.timestamp).getHours()] += 1
  })

  return counts
})

const hourlyMax = computed(() => Math.max(1, ...hourlyOccupancy.value))

const occupancyPeak = computed(() => {
  const max = Math.max(...hourlyOccupancy.value)
  const hour = hourlyOccupancy.value.findIndex((count) => count === max)

  return { hour: hour === -1 ? 0 : hour, count: max }
})

const productsByQuantity = computed(() => {
  return [...posStore.salesByProduct].sort((a, b) => b.qty - a.qty)
})

const productsByRevenue = computed(() => {
  return [...posStore.salesByProduct].sort((a, b) => b.revenue - a.revenue)
})

const topRevenueProduct = computed(() => productsByRevenue.value[0] || null)

const detailTitle = computed(() => {
  const titles = {
    occupancy: 'Detalle de ocupación',
    sales: 'Detalle de ventas',
    revenue: 'Detalle de ingresos',
    stock: 'Detalle de stock bajo',
  }

  return titles[detailMetric.value] || 'Detalle'
})
</script>

<template>
  <div class="space-y-8">
    <!-- Header -->
    <div class="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 class="text-3xl font-black sm:text-4xl">
          {{
            isAdmin
              ? 'Dashboard administrativo'
              : isOwner
                ? 'Dashboard de la sucursal'
                : isTrainer
                  ? 'Dashboard de entrenador'
                  : 'Dashboard'
          }}
        </h1>

        <p class="mt-2 text-sm text-[var(--color-text-secondary)] sm:text-base">
          {{
            isAdmin
              ? 'Resumen operativo de la plataforma'
              : isOwner
                ? 'Resumen operativo de tu sucursal'
                : isTrainer
                  ? 'Resumen de tu jornada y actividad'
                  : 'Resumen general'
          }}
        </p>
      </div>

      <div class="flex flex-wrap gap-3">
        <RouterLink v-if="isManager" to="/dashboard/members">
          <BaseButton variant="secondary"> Miembros </BaseButton>
        </RouterLink>

        <RouterLink v-if="isManager" to="/dashboard/users">
          <BaseButton variant="secondary"> Usuarios </BaseButton>
        </RouterLink>

        <RouterLink v-if="isAdmin" to="/dashboard/branches">
          <BaseButton variant="secondary"> Sucursales </BaseButton>
        </RouterLink>

        <RouterLink
          v-if="(isManager || isTrainer) && moduleStore.isModuleEnabled('pos')"
          to="/dashboard/pos"
        >
          <BaseButton variant="secondary"> POS </BaseButton>
        </RouterLink>

        <RouterLink v-if="moduleStore.isModuleEnabled('calendar')" to="/dashboard/calendar">
          <BaseButton variant="secondary"> Calendario </BaseButton>
        </RouterLink>

        <RouterLink
          v-if="!isManager && !isTrainer && moduleStore.isModuleEnabled('checkin')"
          to="/dashboard/checkin"
        >
          <BaseButton variant="secondary"> Check-in </BaseButton>
        </RouterLink>

        <RouterLink
          v-if="!isManager && !isTrainer && moduleStore.isModuleEnabled('routines')"
          to="/dashboard/routine"
        >
          <BaseButton variant="secondary"> Mi rutina </BaseButton>
        </RouterLink>
      </div>
    </div>

    <!-- Cifras calculadas por SQL sobre TODO el rango, no solo 100 filas. -->
    <BaseCard v-if="isManager && branches.activeBranchId">
      <div class="space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 class="text-2xl font-bold">Resumen del día</h2>
            <p class="text-sm text-[var(--color-text-secondary)]">
              Actividad del {{ daily?.from || todayISO }}. Ventas y pagos de membresías por
              separado.
            </p>
          </div>
          <BaseButton
            variant="secondary"
            :disabled="summary.loading"
            @click="summary.load(branches.activeBranchId).catch(() => {})"
            >Actualizar</BaseButton
          >
        </div>
        <p v-if="summary.loading">Cargando indicadores…</p>
        <p v-if="summary.error" role="alert" class="text-red-400">{{ summary.error }}</p>
        <div v-if="daily" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p class="text-sm text-[var(--color-text-secondary)]">Miembros activos</p>
            <p class="text-2xl font-black">{{ daily.members?.active ?? '—' }}</p>
          </div>
          <div>
            <p class="text-sm text-[var(--color-text-secondary)]">Accesos concedidos / denegados</p>
            <p class="text-2xl font-black">
              {{ daily.checkins?.granted ?? '—' }} / {{ daily.checkins?.denied ?? '—' }}
            </p>
          </div>
          <div>
            <p class="text-sm text-[var(--color-text-secondary)]">
              Ventas ({{ daily.sales?.count ?? 0 }})
            </p>
            <p class="text-2xl font-black">{{ money(daily.sales?.revenue) }}</p>
          </div>
          <div>
            <p class="text-sm text-[var(--color-text-secondary)]">
              Pagos membresías ({{ daily.payments?.count ?? 0 }})
            </p>
            <p class="text-2xl font-black">{{ money(daily.payments?.collected) }}</p>
          </div>
        </div>
      </div>
    </BaseCard>

    <!-- Manager stats -->
    <div v-if="isManager" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Miembros activos</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ activeMembers }}</h3>
      </BaseCard>

      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Entrenadores activos</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ activeTrainers }}</h3>
      </BaseCard>

      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Clases hoy</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ todayClasses.length }}</h3>
      </BaseCard>

      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Check-ins hoy (últimos 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ todayCheckins.length }}</h3>
      </BaseCard>
    </div>

    <!-- Manager secondary stats -->
    <div v-if="isManager" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <BaseCard class="cursor-pointer" @click="openDetail('occupancy')">
        <p class="text-[var(--color-text-secondary)]">Ocupación de clases</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">
          {{ occupancy == null ? 'Sin dato' : `${occupancy}%` }}
        </h3>
      </BaseCard>

      <BaseCard class="cursor-pointer" @click="openDetail('sales')">
        <p class="text-[var(--color-text-secondary)]">Ventas POS hoy (últimas 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ posSalesToday.length }}</h3>
      </BaseCard>

      <BaseCard class="cursor-pointer" @click="openDetail('revenue')">
        <p class="text-[var(--color-text-secondary)]">Ingresos POS hoy (últimas 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">${{ posRevenueToday }}</h3>
      </BaseCard>

      <BaseCard class="cursor-pointer" @click="openDetail('stock')">
        <p class="text-[var(--color-text-secondary)]">Stock bajo</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ lowStockCount }}</h3>
      </BaseCard>
    </div>

    <!-- Trainer stats -->
    <div v-if="isTrainer" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Clases hoy</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ todayClasses.length }}</h3>
      </BaseCard>

      <BaseCard>
        <p class="text-[var(--color-text-secondary)]">Check-ins hoy (últimos 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ todayCheckins.length }}</h3>
      </BaseCard>

      <BaseCard class="cursor-pointer" @click="openDetail('sales')">
        <p class="text-[var(--color-text-secondary)]">Ventas POS hoy (últimas 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">{{ posSalesToday.length }}</h3>
      </BaseCard>

      <BaseCard class="cursor-pointer" @click="openDetail('revenue')">
        <p class="text-[var(--color-text-secondary)]">Ingresos POS hoy (últimas 100)</p>
        <h3 class="text-4xl font-black mt-4 sm:text-5xl">${{ posRevenueToday }}</h3>
      </BaseCard>
    </div>

    <!-- Main content -->
    <div class="grid gap-6 xl:grid-cols-2">
      <!-- Agenda -->
      <BaseCard v-if="moduleStore.isModuleEnabled('calendar')">
        <div class="space-y-4">
          <div class="flex items-center justify-between gap-4">
            <h2 class="text-2xl font-bold">Agenda de hoy</h2>

            <RouterLink to="/dashboard/calendar">
              <BaseButton variant="secondary"> Ver calendario </BaseButton>
            </RouterLink>
          </div>

          <div v-if="!todaySchedule.length" class="text-[var(--color-text-secondary)]">
            No hay clases programadas para hoy
          </div>

          <div
            v-for="branchClass in todaySchedule"
            :key="branchClass.id"
            class="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]/50 p-4 flex flex-col gap-2 md:flex-row md:items-center md:justify-between"
          >
            <div>
              <p class="font-semibold">
                {{ branchClass.name }}
              </p>

              <p class="text-sm text-[var(--color-text-secondary)]">
                {{ branchClass.startTime }} - {{ branchClass.endTime }} · {{ branchClass.capacity }} cupos
              </p>
            </div>

            <div class="text-sm text-[var(--color-text-secondary)]">
              {{ branchClass.attendees?.length || 0 }} inscritos
            </div>
          </div>
        </div>
      </BaseCard>

      <!-- Manager activity -->
      <BaseCard v-if="isManager">
        <div class="space-y-4">
          <div class="flex items-center justify-between gap-4">
            <h2 class="text-2xl font-bold">Actividad reciente</h2>

            <RouterLink v-if="moduleStore.isModuleEnabled('checkin')" to="/dashboard/checkin-audit">
              <BaseButton variant="secondary"> Auditoría </BaseButton>
            </RouterLink>
          </div>

          <div v-if="!adminActivity.length" class="text-[var(--color-text-secondary)]">
            No hay actividad reciente
          </div>

          <div
            v-for="activity in adminActivity"
            :key="activity.id"
            class="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]/50 p-4 flex flex-col gap-1 md:flex-row md:items-center md:justify-between"
          >
            <div>
              <p class="font-semibold">
                {{ activity.title }}
              </p>

              <p class="text-sm text-[var(--color-text-secondary)]">
                {{ activity.description }}
              </p>
            </div>

            <div class="text-right">
              <p
                class="text-xs rounded-full bg-[var(--color-primary)]/15 px-2 py-1 text-[var(--color-primary)]"
              >
                {{ activity.type }}
              </p>

              <p class="text-xs text-[var(--color-text-secondary)] mt-1">
                {{ new Date(activity.timestamp).toLocaleString() }}
              </p>
            </div>
          </div>
        </div>
      </BaseCard>

      <!-- Trainer sales -->
      <BaseCard v-if="isTrainer">
        <div class="space-y-4">
          <div class="flex items-center justify-between gap-4">
            <h2 class="text-2xl font-bold">Mis ventas recientes</h2>

            <RouterLink to="/dashboard/pos">
              <BaseButton variant="secondary"> POS </BaseButton>
            </RouterLink>
          </div>

          <div v-if="!trainerSales.length" class="text-[var(--color-text-secondary)]">
            Aún no tienes ventas registradas
          </div>

          <div
            v-for="sale in trainerSales"
            :key="sale.id"
            class="rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]/50 p-4 flex flex-col gap-1 md:flex-row md:items-center md:justify-between"
          >
            <div>
              <p class="font-semibold">Venta #{{ sale.id }}</p>

              <p class="text-sm text-[var(--color-text-secondary)]">
                {{ sale.items.map((item) => `${item.name} x${item.qty}`).join(', ') }}
              </p>
            </div>

            <div class="text-right">
              <p class="font-bold">${{ sale.total }}</p>

              <p class="text-xs text-[var(--color-text-secondary)] mt-1">
                {{ new Date(sale.createdAt).toLocaleString() }}
              </p>
            </div>
          </div>
        </div>
      </BaseCard>

      <BaseModal :open="detailOpen" @close="closeDetail">
        <div class="space-y-6">
          <div class="flex items-center justify-between gap-4">
            <h2 class="text-2xl font-black sm:text-3xl">
              {{ detailTitle }}
            </h2>

            <BaseButton variant="secondary" @click="closeDetail"> Cerrar </BaseButton>
          </div>

          <!-- Occupancy detail -->
          <div v-if="detailMetric === 'occupancy'" class="space-y-5">
            <BaseCard>
              <div class="space-y-2">
                <p class="text-[var(--color-text-secondary)]">Ocupación de clases no disponible</p>
                <h3 class="text-4xl font-black sm:text-5xl">
                  {{ occupancy == null ? 'Sin dato' : `${occupancy}%` }}
                </h3>
                <p class="text-[var(--color-text-secondary)]">
                  La gráfica presenta los accesos registrados durante el periodo.
                </p>
              </div>
            </BaseCard>

            <BaseCard>
              <div class="space-y-4">
                <h3 class="text-2xl font-bold">Ocupación por hora</h3>

                <div class="overflow-x-auto pb-1">
                  <div class="flex h-56 min-w-[520px] items-end gap-1">
                    <div
                      v-for="(count, hour) in hourlyOccupancy"
                      :key="hour"
                      class="flex flex-1 flex-col items-center gap-1"
                    >
                      <div
                        class="w-full rounded-t-md bg-[var(--color-primary)]/70"
                        :style="{ height: `${Math.max(4, (count / hourlyMax) * 100)}%` }"
                        :title="`${hour}:00 - ${count} check-ins`"
                      />

                      <span
                        v-if="hour % 3 === 0"
                        class="text-[10px] text-[var(--color-text-secondary)]"
                      >
                        {{ hour }}h
                      </span>
                    </div>
                  </div>
                </div>

                <p class="text-[var(--color-text-secondary)]">
                  Pico: {{ occupancyPeak.hour }}:00 con {{ occupancyPeak.count }} check-in(s)
                </p>
              </div>
            </BaseCard>
          </div>

          <!-- Sales detail -->
          <div v-if="detailMetric === 'sales'" class="space-y-4">
            <BaseCard>
              <div class="space-y-2">
                <p class="text-[var(--color-text-secondary)]">Ventas de hoy</p>
                <h3 class="text-4xl font-black sm:text-5xl">
                  {{ posSalesToday.length }}
                </h3>
              </div>
            </BaseCard>

            <div v-if="!productsByQuantity.length" class="text-[var(--color-text-secondary)]">
              No hay productos vendidos todavía
            </div>

            <BaseCard v-for="product in productsByQuantity" :key="product.productId">
              <div class="flex items-center justify-between gap-4">
                <div>
                  <p class="font-semibold">
                    {{ product.name }}
                  </p>
                  <p class="text-sm text-[var(--color-text-secondary)]">
                    {{ product.qty }} unidades vendidas
                  </p>
                </div>
                <p class="font-bold">${{ product.revenue }}</p>
              </div>
            </BaseCard>
          </div>

          <!-- Revenue detail -->
          <div v-if="detailMetric === 'revenue'" class="space-y-4">
            <BaseCard>
              <div class="space-y-2">
                <p class="text-[var(--color-text-secondary)]">Ingresos de hoy</p>
                <h3 class="text-4xl font-black sm:text-5xl">${{ posRevenueToday }}</h3>

                <p v-if="topRevenueProduct" class="text-[var(--color-text-secondary)]">
                  Producto con más ingresos: {{ topRevenueProduct.name }} (${{
                    topRevenueProduct.revenue
                  }})
                </p>
              </div>
            </BaseCard>

            <div v-if="!productsByRevenue.length" class="text-[var(--color-text-secondary)]">
              No hay ingresos registrados
            </div>

            <BaseCard v-for="product in productsByRevenue" :key="product.productId">
              <div class="flex items-center justify-between gap-4">
                <div>
                  <p class="font-semibold">
                    {{ product.name }}
                  </p>
                  <p class="text-sm text-[var(--color-text-secondary)]">
                    {{ product.qty }} unidades
                  </p>
                </div>
                <p class="font-bold">${{ product.revenue }}</p>
              </div>
            </BaseCard>
          </div>

          <!-- Stock detail -->
          <div v-if="detailMetric === 'stock'" class="space-y-4">
            <div
              v-if="!posStore.lowStockProducts.length"
              class="text-[var(--color-text-secondary)]"
            >
              No hay productos con stock bajo
            </div>

            <BaseCard v-for="product in posStore.lowStockProducts" :key="product.id">
              <div class="flex items-center justify-between gap-4">
                <div>
                  <p class="font-semibold">
                    {{ product.name }}
                  </p>
                  <p class="text-sm text-[var(--color-text-secondary)]">
                    {{ product.category }} · SKU {{ product.sku }}
                  </p>
                </div>
                <p class="font-bold text-red-400">Stock: {{ product.stock }}</p>
              </div>
            </BaseCard>
          </div>
        </div>
      </BaseModal>
    </div>
  </div>
</template>
