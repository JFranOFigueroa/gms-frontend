<script setup>
import { ref } from 'vue'

import BaseCard from '@/components/ui/BaseCard.vue'

import BaseInput from '@/components/ui/BaseInput.vue'

import BaseButton from '@/components/ui/BaseButton.vue'

import { useClassTemplateStore } from '@/stores/useClassTemplateStore'

const templateStore = useClassTemplateStore()
const actionError = ref('')

const name = ref('')

const color = ref('#22c55e')

const duration = ref(60)

const capacity = ref(20)

const addTemplate = async () => {
  if (!name.value) return

  try {
    await templateStore.addTemplate({
      name: name.value,
      color: color.value,
      duration: duration.value,
      capacity: capacity.value,
    })
    name.value = ''
    actionError.value = ''
  } catch (error) {
    actionError.value = error.message
  }
}
</script>

<template>
  <div class="space-y-8">
    <!-- HEADER -->
    <div>
      <h1 class="text-3xl font-black sm:text-4xl">Plantillas de clases</h1>

      <p class="mt-2 text-sm text-[var(--color-text-secondary)] sm:text-base">
        Gestiona los tipos de entrenamiento
      </p>
    </div>

    <p v-if="actionError" role="alert" class="text-red-400">{{ actionError }}</p>
    <!-- FORM -->
    <BaseCard>
      <div class="space-y-4">
        <BaseInput v-model="name" placeholder="Nombre clase" />

        <div class="grid gap-4 sm:grid-cols-2">
          <input
            v-model="color"
            type="color"
            class="h-14 w-full rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]"
          />

          <BaseInput v-model="duration" type="number" placeholder="Duración" />
        </div>

        <BaseInput v-model="capacity" type="number" placeholder="Capacidad" />

        <BaseButton @click="addTemplate"> Crear plantilla </BaseButton>
      </div>
    </BaseCard>

    <!-- LIST -->
    <div class="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
      <BaseCard v-for="template in templateStore.templates" :key="template.id">
        <div class="space-y-4">
          <div class="flex items-center gap-3">
            <div
              class="w-5 h-5 rounded-full"
              :style="{
                background: template.color,
              }"
            />

            <h2 class="text-2xl font-bold">
              {{ template.name }}
            </h2>
          </div>

          <div class="text-[var(--color-text-secondary)] space-y-1">
            <p>
              Duración:
              {{ template.duration }} min
            </p>

            <p>
              Capacidad:
              {{ template.capacity }}
            </p>
          </div>
        </div>
      </BaseCard>
    </div>
  </div>
</template>
