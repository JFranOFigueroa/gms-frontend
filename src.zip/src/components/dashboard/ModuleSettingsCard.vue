<script setup>
import { computed, ref } from 'vue'

import BaseCard from '@/components/ui/BaseCard.vue'
import BaseButton from '@/components/ui/BaseButton.vue'

import { useAuthStore } from '@/stores/useAuthStore'
import { useModuleStore } from '@/stores/useModuleStore'
import { moduleRegistry } from '@/config/moduleRegistry'

const authStore = useAuthStore()
const moduleStore = useModuleStore()

const canManage = computed(() => authStore.user?.platformAdmin === true)
const actionError = ref('')

const presets = [
  { id: 'traditional', label: 'Tradicional' },
  { id: 'crossfit', label: 'CrossFit / Clases' },
  { id: 'mixed', label: 'Mixto' },
]

const activePreset = computed(() => {
  const { calendar, routines } = moduleStore.modules

  if (calendar && routines) return 'mixed'
  if (calendar && !routines) return 'crossfit'
  if (!calendar && routines) return 'traditional'

  return null
})

const toggleModule = async (moduleId) => {
  if (!canManage.value) return
  try {
    await moduleStore.toggleModule(moduleId)
    actionError.value = ''
  } catch (e) {
    actionError.value = e.message
  }
}

const applyPreset = async (presetId) => {
  if (!canManage.value) return
  try {
    await moduleStore.applyPreset(presetId)
    actionError.value = ''
  } catch (e) {
    actionError.value = e.message
  }
}
</script>

<template>
  <BaseCard>
    <div class="space-y-6">
      <div>
        <h2 class="text-xl font-black sm:text-2xl">Módulos de la sucursal</h2>

        <p class="mt-2 text-sm text-[var(--color-text-secondary)] sm:text-base">
          Activa o desactiva funcionalidades según el tipo de sucursal
        </p>
      </div>

      <p v-if="!canManage" class="text-sm text-[var(--color-text-secondary)]">
        Solo el administrador del sistema puede cambiar estas opciones.
      </p>
      <p v-if="actionError" role="alert" class="text-red-400">{{ actionError }}</p>
      <div class="space-y-4">
        <div
          v-for="module in moduleRegistry"
          :key="module.id"
          class="flex flex-col gap-3 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]/50 p-4 sm:flex-row sm:items-center sm:justify-between sm:gap-4"
        >
          <div class="min-w-0">
            <div class="flex items-center gap-3">
              <span class="text-2xl">{{ module.icon }}</span>

              <h3 class="text-lg font-bold sm:text-xl">
                {{ module.label }}
              </h3>
            </div>

            <p class="mt-1 text-sm text-[var(--color-text-secondary)]">
              {{ module.description }}
            </p>
          </div>

          <BaseButton
            variant="secondary"
            class="self-start sm:self-auto"
            :disabled="!canManage"
            @click="toggleModule(module.id)"
            :class="{
              '!border-[var(--color-primary)]': moduleStore.isModuleEnabled(module.id),
            }"
          >
            {{ moduleStore.isModuleEnabled(module.id) ? 'Activo' : 'Inactivo' }}
          </BaseButton>
        </div>
      </div>

      <div class="space-y-3">
        <p class="text-sm text-[var(--color-text-secondary)]">Modo rápido</p>

        <div class="flex flex-wrap gap-3">
          <BaseButton
            v-for="preset in presets"
            :key="preset.id"
            variant="secondary"
            @click="applyPreset(preset.id)"
            :class="{
              '!border-[var(--color-primary)]': activePreset === preset.id,
            }"
          >
            {{ preset.label }}
          </BaseButton>
        </div>
      </div>
    </div>
  </BaseCard>
</template>
