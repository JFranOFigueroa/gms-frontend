<script setup>
import { computed } from 'vue'

import { RouterLink } from 'vue-router'

import { sidebarNavigation } from '@/config/sidebarNavigation'

import { useAuthStore } from '@/stores/useAuthStore'

import { useModuleStore } from '@/stores/useModuleStore'

import BaseButton from '@/components/ui/BaseButton.vue'

import { useRouter } from 'vue-router'

import { useTenantStore } from '@/stores/useTenantStore'

const tenantStore = useTenantStore()
const authStore = useAuthStore()
const publicHome = '/'

const moduleStore = useModuleStore()

const navigation = computed(() => {
  return (sidebarNavigation[authStore.role] || []).filter((item) => {
    return !item.module || moduleStore.isModuleEnabled(item.module)
  })
})

const router = useRouter()

const logout = async () => {
  await authStore.logout()

  router.push('/')
}
</script>

<template>
  <aside
    class="fixed left-0 top-0 hidden h-dvh w-72 flex-col overflow-hidden border-r border-[var(--color-border)] bg-[var(--color-surface)] lg:flex"
  >
    <!-- HEADER -->
    <div class="p-6 border-b border-[var(--color-border)]">
      <RouterLink
        :to="publicHome"
        class="font-black leading-tight break-words text-xl xl:text-2xl 2xl:text-3xl max-w-full"
      >
        {{ tenantStore.branch.shortName }}
      </RouterLink>

      <p class="text-[var(--color-text-secondary)] mt-2 text-sm leading-relaxed break-words">
        {{ tenantStore.branch.name }}
      </p>
    </div>

    <!-- NAV -->
    <nav class="flex-1 space-y-2 overflow-y-auto p-4">
      <RouterLink
        v-for="item in navigation"
        :key="item.path"
        :to="item.path"
        class="flex items-center px-4 py-3 rounded-2xl hover:bg-[var(--color-surface-hover)] transition-all"
      >
        {{ item.label }}
      </RouterLink>
    </nav>

    <div class="mt-auto shrink-0 border-t border-[var(--color-border)] p-4">
      <BaseButton class="w-full" variant="secondary" @click="logout"> Cerrar sesión </BaseButton>
    </div>
  </aside>
</template>
